// ========================================================================
//  index.js — نقطة تشغيل السيرفر على Node.js (Railway)
//  بيحوّل أي طلب HTTP عادي (من Node) لصيغة Request/Response القياسية
//  اللي worker.js متوقعها (لأنه كان مكتوب أصلاً كـ Cloudflare Worker)،
//  وبيكلم دالة fetch(request, env) الموجودة جواه من غير ما نلمس منطق
//  السيرفر نفسه.
// ========================================================================

import { createServer } from 'node:http';
import { webcrypto } from 'node:crypto';
import worker from './worker.js';

// بعض إصدارات Node (18) محتاجة polyfill لـ crypto.subtle كـ global،
// لأن worker.js بيستخدم crypto.subtle للتحقق من توقيع Telegram initData.
if (!globalThis.crypto) {
  globalThis.crypto = webcrypto;
}

const PORT = process.env.PORT || 3000;

const server = createServer(async (req, res) => {
  try {
    // Railway بيحط التطبيق خلف Proxy، فـ req.headers.host بيكون صحيح
    // (اسم الدومين اللي المستخدم داخل عليه) — مش محتاجين IP/Port حقيقيين هنا
    // لأننا بنستخدمهم بس لبناء كائن URL صالح.
    const url = `http://${req.headers.host || 'localhost'}${req.url}`;

    const headers = new Headers();
    for (const [key, value] of Object.entries(req.headers)) {
      if (value == null) continue;
      headers.set(key, Array.isArray(value) ? value.join(', ') : value);
    }

    let body;
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      const chunks = [];
      for await (const chunk of req) chunks.push(chunk);
      if (chunks.length) body = Buffer.concat(chunks);
    }

    const request = new Request(url, {
      method: req.method,
      headers,
      body,
    });

    const response = await worker.fetch(request, process.env);

    const resHeaders = {};
    response.headers.forEach((value, key) => {
      resHeaders[key] = value;
    });

    res.writeHead(response.status, resHeaders);
    const buf = Buffer.from(await response.arrayBuffer());
    res.end(buf);
  } catch (err) {
    console.error('خطأ غير متوقع في السيرفر:', err);
    res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: false, error: 'Internal Server Error: ' + err.message }));
  }
});

server.listen(PORT, () => {
  console.log(`✅ السيرفر شغال على المنفذ ${PORT}`);
});

# PMT Gram Backend — نسخة Railway

السيرفر ده كان شغال أصلاً على Cloudflare Workers، وتم تجهيزه هنا عشان يشتغل
على Railway من غير أي تغيير في منطق العمل (نفس المكافآت، نفس التحقق من
Telegram، نفس التعامل مع Firebase).

## إيه اللي اتغيّر بالظبط؟

- `worker.js` هو نفسه الملف القديم (نفس اسم الدالة `fetch(request, env)`)،
  اتغيّر فيه حاجتين بس:
  1. بدل `CF-Connecting-IP` (هيدر خاص بشبكة Cloudflare)، بقينا نقرأ
     `X-Forwarded-For` / `X-Real-IP` اللي Railway بيحطهم.
  2. تعليق توضيحي في الأعلى بس.
- `index.js` ملف جديد — بيشغّل سيرفر Node.js عادي، وبيحوّل كل طلب HTTP
  لصيغة `Request`/`Response` القياسية اللي `worker.js` متوقعها، فيبقى
  زي ما هو شغال على Cloudflare بالظبط.
- `package.json` — عشان Railway يعرف يشغّل المشروع بـ `npm start`.

كل متغيرات البيئة (`FIREBASE_DATABASE_URL`, `BOT_TOKEN`, ...) هي هي زي ما
كانت، بس بدل ما تتحط في Cloudflare Dashboard، هتتحط في Railway.

## خطوات النشر على Railway

1. اعمل ريبو جديد على GitHub وارفع فيه محتوى المجلد ده (أو استخدم
   `railway up` من الـ CLI مباشرة من غير GitHub لو حابب).
2. من [railway.app](https://railway.app) اعمل **New Project** ثم
   **Deploy from GitHub repo** واختار الريبو.
3. من تبويب **Variables** ضيف نفس المتغيرات اللي كانت في Cloudflare:
   - `FIREBASE_DATABASE_URL` (مطلوب)
   - `BOT_TOKEN` (احتياطي — الأساسي بيتقرأ من Firebase)
   - `BOT_USERNAME` (احتياطي)
   - `TONCENTER_API_KEY` (لو بتستخدم تحويل PMT→TON)
   - `TURNSTILE_SECRET_KEY` (احتياطي)
   - راجع `.env.example` في المجلد ده للقائمة كاملة.
4. Railway هيكتشف تلقائيًا إن ده مشروع Node.js (بسبب `package.json`)
   ويشغّل `npm start`. مفيش حاجة تانية محتاجة تظبطها.
5. بعد ما الـ Deploy يخلص، Railway هيديك دومين زي:
   `https://your-app-name.up.railway.app`
   (تقدر كمان تربط دومين خاص بيك من **Settings > Domains**).
6. **مهم جدًا:** روح لملف الواجهة الأمامية (index.html) وغيّر السطر:
   ```js
   var API_URL = 'https://silent-block-bedf.ahmedrabieharoun.workers.dev';
   ```
   إلى دومين Railway الجديد.

## ملاحظة عن رابط TonConnect Manifest

في الكود، رابط الـ `url` جوه `/tonconnect-manifest.json` متكتوب بمسافة غلط:
`https://pmt gram.com` — ده لازم يتصلح لدومين حقيقي (رابط الواجهة الأمامية
الفعلي بتاعتك، مش رابط الـ backend) قبل ما تفتح رابط ربط المحفظة، وإلا
TonConnect ممكن يرفضه.

## تشغيل محلي (اختياري، للتجربة قبل الرفع)

```bash
cp .env.example .env   # وحط فيه قيمك الحقيقية، أو استخدم export مباشرة
npm start
```

السيرفر هيشتغل على `http://localhost:3000` (أو المنفذ اللي في `PORT`).
